using namespace std;

class project_1 : public testing::Test{
    protected:
    virtual void SetUp(){
    }

    char* To_Traversal(Manager m)
    {
        return 'abc';
    }

    template <T>
    T* deserialize(string filename){

        T* result = new T;

        result = open(filename ,'rb');

        return result
    }

}