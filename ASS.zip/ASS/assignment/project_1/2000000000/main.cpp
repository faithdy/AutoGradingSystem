#include "Management.h"
#include<utility>
#include<cstring>
int main()
{
	/*
	std::pair<char[10], char[10]> p1;
	strcpy(p1.first, "asd");

	cout << p1.first << endl;
	*/
	Management m;

	m.ReadCommand();
	return 0;
}
